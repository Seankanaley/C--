﻿namespace FinalsTesting
{
    partial class formFinalTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMiddleName = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtStudentID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtZip = new System.Windows.Forms.TextBox();
            this.txtMajor = new System.Windows.Forms.TextBox();
            this.txtCourse = new System.Windows.Forms.TextBox();
            this.txtCourseQtr = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCourseGrade = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.btnGetName = new System.Windows.Forms.Button();
            this.lblGetName = new System.Windows.Forms.Label();
            this.btnGetAddress = new System.Windows.Forms.Button();
            this.lblGetAddress = new System.Windows.Forms.Label();
            this.btnAddGrade = new System.Windows.Forms.Button();
            this.btnGetGPA = new System.Windows.Forms.Button();
            this.lblGetGPA = new System.Windows.Forms.Label();
            this.btnIsHonorRoll = new System.Windows.Forms.Button();
            this.lblIsHonorRoll = new System.Windows.Forms.Label();
            this.btnGetTime = new System.Windows.Forms.Button();
            this.lblGetTime = new System.Windows.Forms.Label();
            this.dtpEnrolledDate = new System.Windows.Forms.DateTimePicker();
            this.btnGetPassed = new System.Windows.Forms.Button();
            this.lblGetPassed = new System.Windows.Forms.Label();
            this.btnGetFailed = new System.Windows.Forms.Button();
            this.lblGetFailed = new System.Windows.Forms.Label();
            this.btnAddCourse = new System.Windows.Forms.Button();
            this.btnAddQtr = new System.Windows.Forms.Button();
            this.btnAddAll = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(967, 43);
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(198, 31);
            this.txtFirstName.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(967, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(198, 23);
            this.label2.TabIndex = 3;
            this.label2.Text = "First Name";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtMiddleName
            // 
            this.txtMiddleName.Location = new System.Drawing.Point(967, 113);
            this.txtMiddleName.Name = "txtMiddleName";
            this.txtMiddleName.Size = new System.Drawing.Size(198, 31);
            this.txtMiddleName.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(967, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(198, 23);
            this.label3.TabIndex = 3;
            this.label3.Text = "Middle Name";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(967, 181);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(198, 31);
            this.txtLastName.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(967, 151);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(198, 23);
            this.label4.TabIndex = 3;
            this.label4.Text = "Last Name";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtStudentID
            // 
            this.txtStudentID.Location = new System.Drawing.Point(967, 251);
            this.txtStudentID.Name = "txtStudentID";
            this.txtStudentID.Size = new System.Drawing.Size(198, 31);
            this.txtStudentID.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(967, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(198, 23);
            this.label5.TabIndex = 3;
            this.label5.Text = "Student ID";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(967, 320);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(198, 31);
            this.txtEmail.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(967, 290);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(198, 23);
            this.label6.TabIndex = 3;
            this.label6.Text = "Email";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtPhone
            // 
            this.txtPhone.Location = new System.Drawing.Point(967, 389);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(198, 31);
            this.txtPhone.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(967, 359);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(198, 23);
            this.label7.TabIndex = 3;
            this.label7.Text = "Phone";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(967, 465);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(198, 31);
            this.txtAddress.TabIndex = 2;
            // 
            // txtZip
            // 
            this.txtZip.Location = new System.Drawing.Point(967, 535);
            this.txtZip.Name = "txtZip";
            this.txtZip.Size = new System.Drawing.Size(198, 31);
            this.txtZip.TabIndex = 2;
            // 
            // txtMajor
            // 
            this.txtMajor.Location = new System.Drawing.Point(967, 603);
            this.txtMajor.Name = "txtMajor";
            this.txtMajor.Size = new System.Drawing.Size(198, 31);
            this.txtMajor.TabIndex = 2;
            // 
            // txtCourse
            // 
            this.txtCourse.Location = new System.Drawing.Point(967, 742);
            this.txtCourse.Name = "txtCourse";
            this.txtCourse.Size = new System.Drawing.Size(198, 31);
            this.txtCourse.TabIndex = 2;
            // 
            // txtCourseQtr
            // 
            this.txtCourseQtr.Location = new System.Drawing.Point(967, 811);
            this.txtCourseQtr.Name = "txtCourseQtr";
            this.txtCourseQtr.Size = new System.Drawing.Size(198, 31);
            this.txtCourseQtr.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(967, 435);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(198, 23);
            this.label8.TabIndex = 3;
            this.label8.Text = "Address";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(967, 505);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(198, 23);
            this.label9.TabIndex = 3;
            this.label9.Text = "Zip";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.Location = new System.Drawing.Point(967, 647);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(198, 23);
            this.label10.TabIndex = 3;
            this.label10.Text = "Enrolled Date";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(967, 716);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(198, 23);
            this.label11.TabIndex = 3;
            this.label11.Text = "Course ";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(967, 785);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(198, 23);
            this.label12.TabIndex = 3;
            this.label12.Text = "Course Qtr/Yr";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(967, 860);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(198, 23);
            this.label13.TabIndex = 3;
            this.label13.Text = "Course Grade";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtCourseGrade
            // 
            this.txtCourseGrade.Location = new System.Drawing.Point(967, 886);
            this.txtCourseGrade.Name = "txtCourseGrade";
            this.txtCourseGrade.Size = new System.Drawing.Size(198, 31);
            this.txtCourseGrade.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.Location = new System.Drawing.Point(967, 577);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(198, 23);
            this.label14.TabIndex = 3;
            this.label14.Text = "Major";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGetName
            // 
            this.btnGetName.Location = new System.Drawing.Point(13, 13);
            this.btnGetName.Name = "btnGetName";
            this.btnGetName.Size = new System.Drawing.Size(146, 57);
            this.btnGetName.TabIndex = 4;
            this.btnGetName.Text = "GetName";
            this.btnGetName.UseVisualStyleBackColor = true;
            this.btnGetName.Click += new System.EventHandler(this.btnGetName_Click);
            // 
            // lblGetName
            // 
            this.lblGetName.Location = new System.Drawing.Point(165, 13);
            this.lblGetName.Name = "lblGetName";
            this.lblGetName.Size = new System.Drawing.Size(303, 57);
            this.lblGetName.TabIndex = 5;
            this.lblGetName.Text = "Test";
            this.lblGetName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGetAddress
            // 
            this.btnGetAddress.Location = new System.Drawing.Point(492, 13);
            this.btnGetAddress.Name = "btnGetAddress";
            this.btnGetAddress.Size = new System.Drawing.Size(146, 57);
            this.btnGetAddress.TabIndex = 4;
            this.btnGetAddress.Text = "GetAddress";
            this.btnGetAddress.UseVisualStyleBackColor = true;
            this.btnGetAddress.Click += new System.EventHandler(this.btnGetAddress_Click);
            // 
            // lblGetAddress
            // 
            this.lblGetAddress.Location = new System.Drawing.Point(644, 13);
            this.lblGetAddress.Name = "lblGetAddress";
            this.lblGetAddress.Size = new System.Drawing.Size(302, 231);
            this.lblGetAddress.TabIndex = 5;
            this.lblGetAddress.Text = "Test";
            this.lblGetAddress.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAddGrade
            // 
            this.btnAddGrade.Location = new System.Drawing.Point(11, 633);
            this.btnAddGrade.Name = "btnAddGrade";
            this.btnAddGrade.Size = new System.Drawing.Size(146, 57);
            this.btnAddGrade.TabIndex = 4;
            this.btnAddGrade.Text = "AddGrade";
            this.btnAddGrade.UseVisualStyleBackColor = true;
            this.btnAddGrade.Click += new System.EventHandler(this.btnAddGrade_Click);
            // 
            // btnGetGPA
            // 
            this.btnGetGPA.Location = new System.Drawing.Point(12, 76);
            this.btnGetGPA.Name = "btnGetGPA";
            this.btnGetGPA.Size = new System.Drawing.Size(146, 57);
            this.btnGetGPA.TabIndex = 4;
            this.btnGetGPA.Text = "GetGPA";
            this.btnGetGPA.UseVisualStyleBackColor = true;
            this.btnGetGPA.Click += new System.EventHandler(this.btnGetGPA_Click);
            // 
            // lblGetGPA
            // 
            this.lblGetGPA.Location = new System.Drawing.Point(164, 76);
            this.lblGetGPA.Name = "lblGetGPA";
            this.lblGetGPA.Size = new System.Drawing.Size(303, 57);
            this.lblGetGPA.TabIndex = 5;
            this.lblGetGPA.Text = "Test";
            this.lblGetGPA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnIsHonorRoll
            // 
            this.btnIsHonorRoll.Location = new System.Drawing.Point(12, 139);
            this.btnIsHonorRoll.Name = "btnIsHonorRoll";
            this.btnIsHonorRoll.Size = new System.Drawing.Size(146, 57);
            this.btnIsHonorRoll.TabIndex = 4;
            this.btnIsHonorRoll.Text = "IsHonorRoll";
            this.btnIsHonorRoll.UseVisualStyleBackColor = true;
            this.btnIsHonorRoll.Click += new System.EventHandler(this.btnIsHonorRoll_Click);
            // 
            // lblIsHonorRoll
            // 
            this.lblIsHonorRoll.Location = new System.Drawing.Point(164, 139);
            this.lblIsHonorRoll.Name = "lblIsHonorRoll";
            this.lblIsHonorRoll.Size = new System.Drawing.Size(303, 57);
            this.lblIsHonorRoll.TabIndex = 5;
            this.lblIsHonorRoll.Text = "Test";
            this.lblIsHonorRoll.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGetTime
            // 
            this.btnGetTime.Location = new System.Drawing.Point(12, 202);
            this.btnGetTime.Name = "btnGetTime";
            this.btnGetTime.Size = new System.Drawing.Size(146, 57);
            this.btnGetTime.TabIndex = 4;
            this.btnGetTime.Text = "GetTime";
            this.btnGetTime.UseVisualStyleBackColor = true;
            this.btnGetTime.Click += new System.EventHandler(this.btnGetTime_Click);
            // 
            // lblGetTime
            // 
            this.lblGetTime.Location = new System.Drawing.Point(164, 202);
            this.lblGetTime.Name = "lblGetTime";
            this.lblGetTime.Size = new System.Drawing.Size(303, 57);
            this.lblGetTime.TabIndex = 5;
            this.lblGetTime.Text = "Test";
            this.lblGetTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dtpEnrolledDate
            // 
            this.dtpEnrolledDate.Location = new System.Drawing.Point(965, 673);
            this.dtpEnrolledDate.Name = "dtpEnrolledDate";
            this.dtpEnrolledDate.Size = new System.Drawing.Size(200, 31);
            this.dtpEnrolledDate.TabIndex = 6;
            // 
            // btnGetPassed
            // 
            this.btnGetPassed.Location = new System.Drawing.Point(492, 251);
            this.btnGetPassed.Name = "btnGetPassed";
            this.btnGetPassed.Size = new System.Drawing.Size(146, 57);
            this.btnGetPassed.TabIndex = 4;
            this.btnGetPassed.Text = "GetPassed";
            this.btnGetPassed.UseVisualStyleBackColor = true;
            this.btnGetPassed.Click += new System.EventHandler(this.btnGetPassed_Click);
            // 
            // lblGetPassed
            // 
            this.lblGetPassed.Location = new System.Drawing.Point(645, 251);
            this.lblGetPassed.Name = "lblGetPassed";
            this.lblGetPassed.Size = new System.Drawing.Size(302, 233);
            this.lblGetPassed.TabIndex = 5;
            this.lblGetPassed.Text = "Test";
            this.lblGetPassed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnGetFailed
            // 
            this.btnGetFailed.Location = new System.Drawing.Point(490, 509);
            this.btnGetFailed.Name = "btnGetFailed";
            this.btnGetFailed.Size = new System.Drawing.Size(146, 57);
            this.btnGetFailed.TabIndex = 4;
            this.btnGetFailed.Text = "GetFailed";
            this.btnGetFailed.UseVisualStyleBackColor = true;
            this.btnGetFailed.Click += new System.EventHandler(this.btnGetFailed_Click);
            // 
            // lblGetFailed
            // 
            this.lblGetFailed.Location = new System.Drawing.Point(645, 509);
            this.lblGetFailed.Name = "lblGetFailed";
            this.lblGetFailed.Size = new System.Drawing.Size(302, 233);
            this.lblGetFailed.TabIndex = 5;
            this.lblGetFailed.Text = "Test";
            this.lblGetFailed.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAddCourse
            // 
            this.btnAddCourse.Location = new System.Drawing.Point(12, 509);
            this.btnAddCourse.Name = "btnAddCourse";
            this.btnAddCourse.Size = new System.Drawing.Size(146, 57);
            this.btnAddCourse.TabIndex = 4;
            this.btnAddCourse.Text = "AddCourse";
            this.btnAddCourse.UseVisualStyleBackColor = true;
            this.btnAddCourse.Click += new System.EventHandler(this.btnAddCourse_Click);
            // 
            // btnAddQtr
            // 
            this.btnAddQtr.Location = new System.Drawing.Point(11, 572);
            this.btnAddQtr.Name = "btnAddQtr";
            this.btnAddQtr.Size = new System.Drawing.Size(146, 57);
            this.btnAddQtr.TabIndex = 4;
            this.btnAddQtr.Text = "AddQtr/Yr";
            this.btnAddQtr.UseVisualStyleBackColor = true;
            this.btnAddQtr.Click += new System.EventHandler(this.btnAddQtr_Click);
            // 
            // btnAddAll
            // 
            this.btnAddAll.Location = new System.Drawing.Point(170, 572);
            this.btnAddAll.Name = "btnAddAll";
            this.btnAddAll.Size = new System.Drawing.Size(147, 57);
            this.btnAddAll.TabIndex = 7;
            this.btnAddAll.Text = "Add All";
            this.btnAddAll.UseVisualStyleBackColor = true;
            this.btnAddAll.Click += new System.EventHandler(this.btnAddAll_Click);
            // 
            // formFinalTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1177, 1079);
            this.Controls.Add(this.btnAddAll);
            this.Controls.Add(this.dtpEnrolledDate);
            this.Controls.Add(this.lblGetTime);
            this.Controls.Add(this.lblIsHonorRoll);
            this.Controls.Add(this.lblGetGPA);
            this.Controls.Add(this.lblGetFailed);
            this.Controls.Add(this.lblGetPassed);
            this.Controls.Add(this.lblGetAddress);
            this.Controls.Add(this.lblGetName);
            this.Controls.Add(this.btnGetFailed);
            this.Controls.Add(this.btnGetPassed);
            this.Controls.Add(this.btnGetTime);
            this.Controls.Add(this.btnIsHonorRoll);
            this.Controls.Add(this.btnGetGPA);
            this.Controls.Add(this.btnAddQtr);
            this.Controls.Add(this.btnAddCourse);
            this.Controls.Add(this.btnAddGrade);
            this.Controls.Add(this.btnGetAddress);
            this.Controls.Add(this.btnGetName);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCourseGrade);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.txtCourseQtr);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCourse);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtMajor);
            this.Controls.Add(this.txtStudentID);
            this.Controls.Add(this.txtZip);
            this.Controls.Add(this.txtLastName);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.txtMiddleName);
            this.Controls.Add(this.txtFirstName);
            this.Name = "formFinalTest";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMiddleName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtStudentID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.TextBox txtZip;
        private System.Windows.Forms.TextBox txtMajor;
        private System.Windows.Forms.TextBox txtCourse;
        private System.Windows.Forms.TextBox txtCourseQtr;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCourseGrade;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button btnGetName;
        private System.Windows.Forms.Label lblGetName;
        private System.Windows.Forms.Button btnGetAddress;
        private System.Windows.Forms.Label lblGetAddress;
        private System.Windows.Forms.Button btnAddGrade;
        private System.Windows.Forms.Button btnGetGPA;
        private System.Windows.Forms.Label lblGetGPA;
        private System.Windows.Forms.Button btnIsHonorRoll;
        private System.Windows.Forms.Label lblIsHonorRoll;
        private System.Windows.Forms.Button btnGetTime;
        private System.Windows.Forms.Label lblGetTime;
        private System.Windows.Forms.DateTimePicker dtpEnrolledDate;
        private System.Windows.Forms.Button btnGetPassed;
        private System.Windows.Forms.Label lblGetPassed;
        private System.Windows.Forms.Button btnGetFailed;
        private System.Windows.Forms.Label lblGetFailed;
        private System.Windows.Forms.Button btnAddCourse;
        private System.Windows.Forms.Button btnAddQtr;
        private System.Windows.Forms.Button btnAddAll;
    }
}

